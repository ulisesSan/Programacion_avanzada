<?php
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <button onclick="location.href='./conector.php'">Probar Conexón</button>
    <button onclick="location.href='./consulta.php'">Consulta</button>
    <button onclick="location.href='./cerrarConexion.php'">Cerrar conexion</button>
</body>
</html>
