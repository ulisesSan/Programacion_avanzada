<?php
$connector = mysqli_connect(
    'localhost',
    'root',
    '1234',
    'f84_15'
);
?>
