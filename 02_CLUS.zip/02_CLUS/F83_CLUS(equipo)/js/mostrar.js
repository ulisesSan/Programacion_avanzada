function mos1() {
    document.getElementById('t1').style.display="none";
}